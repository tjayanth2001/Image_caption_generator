# Image-Captioning

HuggingFace Space: https://huggingface.co/spaces/pritish/Image-Captioning

![image](https://user-images.githubusercontent.com/55872694/218245040-fea19824-c082-47c1-bc21-0b814e61cc9a.png)
